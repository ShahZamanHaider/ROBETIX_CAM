# Robetix Vision — Phase 1

Standalone AI Thinker **original ESP32-CAM + OV2640** firmware. The supplied workspace was empty; there was no previous `main.cpp`, configuration, or repository to preserve. No serial device was detected during implementation. Compilation is not hardware verification.

## Build and flash

Uses the already installed PlatformIO Espressif32 **6.11.0**, Arduino-ESP32 **2.0.17** (`3.20017.241212` package), its bundled Espressif camera driver, and ArduinoJson **6.21.5**. The board definition enables PSRAM. `huge_app.csv` supplies a 3 MiB application partition; OTA is not implemented. HTML/CSS/JS are compiled into flash, so **no filesystem upload** is needed.

```powershell
& "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" run
& "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" run -t upload
& "$env:USERPROFILE\.platformio\penv\Scripts\platformio.exe" device monitor -b 115200
```

Use `--upload-port COMx` if automatic selection fails. Install the USB base's USB-to-serial driver if no port appears. Some bases require holding BOOT / GPIO0 low during reset for upload; release it and reset afterward. GPIO0 is camera XCLK in normal operation. Disconnect power before swapping the camera ribbon or inserting a card. Use a stable regulated 5 V supply with adequate current headroom (a reputable 1 A or greater supply and short cable is a sensible starting point). Brownout detection remains enabled.

## First use

1. Install the OV2640, connect the board, flash, and read the serial monitor at 115200 baud. Reset if necessary to see startup messages.
2. On an unconfigured camera, connect your phone to **Robetix-Setup**, password **RobetixSetup**. This documented WPA2 password is only for initial setup; serial access is not required to learn a password.
3. If warned that the network has no Internet, stay connected. Open **http://192.168.4.1** manually. Captive DNS redirection is not implemented.
4. Create your own administrator password of 12–64 characters. The web page then opens Network settings. No setup key is required.
5. Choose **AP · Camera creates Wi-Fi** or **STA · Camera joins your router**. Set the camera hotspot name and your own hotspot password (8–63 characters). In STA mode, also scan/select your router's 2.4 GHz Wi-Fi name and enter its Wi-Fi password. The camera hotspot remains available as recovery access in STA mode.
6. Press **Save network and finish setup**. After two seconds Wi-Fi reconnects using your choices. Reconnect the phone to the hotspot name/password you chose and reopen **http://192.168.4.1**. The shared `RobetixSetup` password cannot be kept as the configured hotspot password. Your choices persist across restarts.
7. In STA mode, status shows router connection success/failure and the actual IP. Use **http://robetix.local** on a compatible LAN client, or the displayed IP. mDNS availability depends on the phone/browser/network and may fail on guest networks or across subnets.
8. Start live view. Default viewing uses `object-fit: contain`, preserving the full received image. Fill can crop; 1:1 shows original pixels with scrolling. Digital zoom affects only the display. Software cannot widen a physical lens's field of view. SXGA is 5:4; other exposed sizes are 4:3, so compare field of view using matching aspect ratios.

Change AP/STA mode, camera hotspot name/password, and router credentials later under **Network** after signing in. Leave the camera hotspot password empty to retain the current one after initial setup. Saving router settings requires re-entering the router password (empty means an open router network). Saved passwords are never returned by APIs. Changing network settings interrupts Wi-Fi after the response, and the page gives reconnection instructions.

The protected AP stays available in both modes as the recovery path. It supports two associated stations; the server supports **one live stream**. Router retries back off from 10 to 120 seconds without erasing credentials. Scanning or switching the router channel can briefly interrupt the AP and stream. No Internet, cloud, computer, Pi or inference server is required at runtime.

Upgrade note: flashing this version over an older installation with no administrator configured replaces the serial-only onboarding path with `Robetix-Setup` / `RobetixSetup`. Already configured installations retain their previous administrator and hotspot credentials; use Network to change them. No flash erase is needed for a normal update.

If administrator access is lost, physically erase flash using PlatformIO `run -t erase`, then upload again. **This intentionally erases all saved settings and restores the initial setup hotspot**, but does not erase the SD card. Do not use erase for normal updates.

## Camera and diagnostics

The driver probes the sensor over SCCB during `esp_camera_init`. Firmware requests **PIXFORMAT_JPEG**, reports available PID/version/manufacturer registers, and refuses capture unless PID equals `OV2640_PID` (0x26 in this driver). This verifies the reported sensor identity, not module provenance. A failed native-JPEG probe remains a visible error; there is **no RGB565/software JPEG fallback**. If initialization fails before sensor data can be retained, read the driver's serial probe messages. The actual connected sensor has not yet been verified here.

Boot starts at VGA, JPEG quality 16, one buffer in PSRAM; without detected PSRAM it starts at QVGA in internal RAM. Saved valid image controls are then applied. Supported controls: QVGA/VGA/SVGA/XGA/SXGA/UXGA, native JPEG quality 10–40 (lower is higher quality), brightness/contrast/saturation -2…2, horizontal mirror and vertical flip. Exposure/gain/white balance remain at driver auto defaults. Unsupported sensors have no capture path.

Higher resolutions are session-only to preserve a safe boot recovery path. Other image settings persist. Changing resolution reinitializes the driver to allocate an appropriately sized buffer. If allocation fails, camera capture stops with a diagnostic; reboot restores conservative initialization. There is no claim that every resolution/quality will fit or sustain streaming on every module.

Camera ownership is serialized by one mutex. Every acquired framebuffer is returned on success and failure paths. Streaming is on port 81; control, snapshots and setup are on port 80, allowing control requests while a stream is open. Stream writes have a 2-second socket timeout; camera-control requests have a bounded lock wait. Slow clients and SD operations can still cause frame stalls. Streaming is paced to **at most 10 FPS**, a configured ceiling, not a measured performance promise. The displayed stream FPS measures completed sends over the current stream session, not browser decoding. No synthetic temperature or JPEG conversion time is shown: no software conversion is performed.

When no viewer or snapshot/benchmark request exists, firmware does not call `fb_get` in a loop. The single-buffer driver can retain a frame, and the sensor remains powered; this is not deep sleep or a guarantee of zero camera activity. Hidden browser pages stop their stream; explicitly restart it when returning. Stream failure also requires pressing Start again.

## microSD snapshots

Use a FAT32 card, inserted **with power off**, then reboot. SD_MMC uses **1-bit mode, 20 MHz**, with CLK GPIO14, CMD GPIO15, D0 GPIO2. GPIO4 flash LED is kept low and is not used as SD D1. Camera pins follow AI Thinker mapping; no custom external GPIO assignment is needed. GPIO2/15 are boot-related pins; remove the card while troubleshooting upload/boot failures. Do not change board pull-ups without checking the actual board schematic.

Missing or unmountable cards do not prevent streaming or browser snapshots. Mounted status, filesystem capacity/free space and manual JPEG saving appear in the dashboard. Files are named with random identifiers under `/snapshots/`; names **do not represent date/time**. No external time source is required. The firmware never autoformats the card, deletes old captures, or exposes unauthenticated downloads. Read saved files with a card reader after powering off. Browser SD file browsing/download/deletion is deferred to Phase 2.

Writes check the number of bytes accepted and close/flush the file. A write failure disables further saves until restart. The slot has no reliable card-presence switch: removal may only be noticed on an I/O operation, and status can remain stale until then. Filesystem/free-space queries and failing cards can block in the underlying SD driver; hot-plug is unsupported. A successful software write does not prove power-loss durability. There is no video recording, H.264, MP4, or AVI support in this phase.

## Benchmark and hardware acceptance

Press **Run resolution / quality benchmark** with a static but detailed scene. It pauses streaming, discards three warm-up frames per configuration, then measures 30 frames each at JPEG qualities 12 and 20 for QVGA through UXGA (QVGA only without PSRAM). Results include actual capture FPS, average JPEG bytes, failed frames, free heap and free PSRAM; results remain in RAM until reboot. It restores previous settings if the camera remains initialized. A failed reinitialization stops the test and may require reboot. Save the JSON results before restarting.

These are capture-only measurements with Wi-Fi active, **not end-to-end streaming FPS, SD throughput or a stability certificate**. Test higher resolutions separately while streaming and saving SD snapshots. Monitor capture failures, minimum heap, free PSRAM and resets over at least an overnight run before choosing a daily configuration. Frame validity checks JPEG markers/format, not a full decode or image-quality assessment.

Hardware checklist (all pending on the actual board):

- Confirm PID 0x26, native JPEG, PSRAM size and clean QVGA/VGA images in serial/dashboard.
- Sign in from phone, download a JPEG, verify full-frame fit, orientation and quality changes.
- Confirm passwords/settings survive reset, and wrong-password/unauthenticated API access is rejected.
- Run benchmark; then compare real stream FPS and visible latency at selected higher resolutions.
- Test absent card, FAT32 card, manual save, full/read-only/failing card behavior and JPEG readability on a card reader.
- Interrupt router power, verify bounded reconnects and continued recovery-AP access; test mDNS and fallback IP.
- Disconnect a stream client mid-frame, attempt a second viewer, expire/sign out a session and confirm recovery.
- Run streaming plus periodic snapshots overnight and inspect resets, free/minimum heap, capture failures, SD errors and power stability. Do not remove an energized card as a routine test.

## Security scope

The public root serves only static application code and a login screen; camera, settings, telemetry, benchmark and snapshots require an authenticated session. Initial administrator creation is available while no administrator exists. The documented bootstrap Wi-Fi password is shared, so initial setup does not establish ownership beyond access to that hotspot; finish setup in a trusted environment and replace it through the form. Once set, administrator credentials are required for further network changes. Session cookies are random, HttpOnly, SameSite=Strict, expire after 12 hours, and are shared across ports on the same hostname. One active session is supported. Sign-in replaces the session; logout/reboot invalidates it. Failed login attempts are globally paced. Mutation APIs accept JSON only and do not grant CORS permissions.

This is basic local-network protection: **HTTP is unencrypted**, and cookies/passwords can be intercepted by a party able to observe LAN traffic. NVS stores salted SHA-256 admin hashes (not a slow password KDF), plus recoverable Wi-Fi/AP credentials. Flash encryption and secure boot are not provisioned. Physical flash extraction and offline password guessing remain risks; use a strong unique password. Use trusted Wi-Fi, never port-forward this camera, and do not describe it as an Internet-ready hardened security appliance. No external font, JS, CDN, telemetry or analytics requests are made.

## Architecture / future work

`Camera` owns acquisition/configuration and the bounded benchmark; `Storage` consumes borrowed JPEG buffers; `Network` manages AP/STA and mDNS; `Settings` owns NVS; `Web` serves authenticated APIs and one stream; `Ui.h` embeds a small responsive vanilla-JS interface. Future capture consumers must obtain the same camera mutex and return frames promptly; they must not introduce independent camera acquisition loops. Recording should start with explicitly labeled JPEG sequences and bounded write pacing, not fictional MP4 encoding.

Motion detection is feasible to investigate by decoding occasional native JPEG frames at reduced scale, converting a small luminance grid, then applying differences, noise thresholds, persistence, cooldown and ROI masks. Do not compare compressed JPEG byte lengths as a reliable motion detector. Measure decoder scratch memory and capture-lock duration first; defer work or skip samples when the camera/storage pipeline is busy. No detector consumes CPU/RAM in this build.

Current ESP-WHO does not support the original ESP32 on its current main branch. Espressif's TFLite Micro person-detection example does document original ESP32 targets and a small quantized model, but that is **not verification of coexistence with this Arduino firmware, OV2640, SD and Wi-Fi**. Porting, tensor-arena sizing, low-resolution input preprocessing, accuracy checks and latency/soak measurements would be necessary. No person detection is implemented or promised, and no external inference service is part of this design.

Eco/Balanced/Quality tuned presets, manual recording, motion detection, event history, scheduling, retention, remote access and human detection remain future work. Named performance profiles should be based on this board's measurements rather than unverified claims. Phase 1 deliberately exposes direct resolution and quality controls instead.

Primary references consulted (implementation APIs checked against installed Arduino 2.0.17 headers):

- [Espressif camera driver: sensor formats, PSRAM, JPEG and buffer behavior](https://github.com/espressif/esp32-camera)
- [Arduino-ESP32 2.0.17](https://github.com/espressif/arduino-esp32/tree/2.0.17)
- [SD_MMC pin mapping and limitations](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/sdmmc.html)
- [ESP-WHO current target limitations](https://github.com/espressif/esp-who)
- [Espressif TFLite Micro person detection](https://github.com/espressif/esp-tflite-micro/tree/master/examples/person_detection)

## API

Public: `GET /`, `GET /api/session`, `POST /api/login` (creates administrator only when one does not yet exist).
Authenticated: `GET /api/status`, `GET /api/snapshot`, `GET /api/scan`, `GET /api/benchmark`, `POST /api/camera`, `POST /api/network`, `POST /api/storage/snapshot`, `POST /api/benchmark`, `POST /api/logout`; `GET :81/stream` uses the same session cookie. JSON input is limited to 768 bytes. There are no recording or file-delete endpoints.

`POST /api/network`: `{ "hotspot": true, "ap_ssid": "My Camera", "ap_password": "your-password", "ssid": "", "password": "" }`. Set `hotspot` false and supply router `ssid`/`password` for STA mode. `ap_password` may be empty only after setup to preserve the current one. Status includes `ap_ssid` and `needs_network_setup`, never either password.
