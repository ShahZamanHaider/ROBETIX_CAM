#include "Camera.h"
#include "Settings.h"
#include <atomic>
namespace Camera {
SemaphoreHandle_t mutex;
std::atomic<bool> ready{false}; uint16_t pid=0; String error;
uint32_t captured=0,failures=0,captureUs=0;
static std::atomic<bool> benchmarking{false};
static portMUX_TYPE benchMux=portMUX_INITIALIZER_UNLOCKED;
struct Result { int size,quality; uint32_t frames,failed,ms,bytes,heap,psram; };
static Result results[12]; static int resultCount=0;
bool busy(){return benchmarking.load();}
static bool validSize(int n) { return n==FRAMESIZE_QVGA || n==FRAMESIZE_VGA || n==FRAMESIZE_SVGA || n==FRAMESIZE_XGA || n==FRAMESIZE_SXGA || n==FRAMESIZE_UXGA; }
bool configure(int size,int quality,int brightness,int contrast,int saturation,int mirror,int flip,bool persist) {
  if(!ready || !validSize(size) || (!psramFound() && size!=FRAMESIZE_QVGA) || quality<10 || quality>40 || abs(brightness)>2 || abs(contrast)>2 || abs(saturation)>2 || mirror<0 || mirror>1 || flip<0 || flip>1) return false;
  sensor_t *s=esp_camera_sensor_get();
  // Reinitialize on resolution changes: driver buffer sizing follows initial resolution.
  if(size!=s->status.framesize) {
    camera_config_t c; esp_camera_deinit(); ready=false;
    extern camera_config_t config;
    c=config; c.frame_size=(framesize_t)size; c.jpeg_quality=quality;
    esp_err_t e=esp_camera_init(&c);
    if(e!=ESP_OK) { error="Camera reinit failed; reboot for safe VGA defaults"; return false; }
    s=esp_camera_sensor_get();
    if(!s || s->id.PID!=OV2640_PID) { esp_camera_deinit(); error="OV2640 identity check failed"; return false; }
    config=c; ready=true;
  }
  int rc=s->set_quality(s,quality) | s->set_brightness(s,brightness) | s->set_contrast(s,contrast) | s->set_saturation(s,saturation) | s->set_hmirror(s,mirror) | s->set_vflip(s,flip);
  if(rc) return false;
  if(persist) {
    prefs.putInt("quality",quality); prefs.putInt("bright",brightness); prefs.putInt("contrast",contrast); prefs.putInt("sat",saturation); prefs.putInt("mirror",mirror); prefs.putInt("flip",flip);
    // Boot resolution intentionally remains conservative; higher resolutions are session-only.
  }
  return true;
}
camera_config_t config={};
bool begin() {
  mutex=xSemaphoreCreateMutex(); if(!mutex) { error="Camera mutex allocation failed"; return false; }
  config.pin_pwdn=32; config.pin_reset=-1; config.pin_xclk=0;
  config.pin_sccb_sda=26; config.pin_sccb_scl=27;
  config.pin_d7=35; config.pin_d6=34; config.pin_d5=39; config.pin_d4=36;
  config.pin_d3=21; config.pin_d2=19; config.pin_d1=18; config.pin_d0=5;
  config.pin_vsync=25; config.pin_href=23; config.pin_pclk=22;
  config.xclk_freq_hz=20000000; config.ledc_timer=LEDC_TIMER_0; config.ledc_channel=LEDC_CHANNEL_0;
  config.pixel_format=PIXFORMAT_JPEG; config.frame_size=psramFound()?FRAMESIZE_VGA:FRAMESIZE_QVGA;
  config.jpeg_quality=16; config.fb_count=1;
  config.fb_location=psramFound()?CAMERA_FB_IN_PSRAM:CAMERA_FB_IN_DRAM;
  config.grab_mode=CAMERA_GRAB_WHEN_EMPTY;
  esp_err_t e=esp_camera_init(&config); sensor_t *s=esp_camera_sensor_get();
  if(s) { pid=s->id.PID; Serial.printf("Sensor PID=0x%04x VER=0x%02x MID=%02x:%02x\n",pid,s->id.VER,s->id.MIDH,s->id.MIDL); }
  if(e!=ESP_OK) { error="Native JPEG init failed (0x"+String(e,HEX)+"). Check serial sensor probe, ribbon and OV2640 module."; return false; }
  if(!s || pid!=OV2640_PID) { esp_camera_deinit(); error="Sensor is not OV2640; capture refused"; return false; }
  ready=true;
  configure(config.frame_size,prefs.getInt("quality",16),prefs.getInt("bright",0),prefs.getInt("contrast",0),prefs.getInt("sat",0),prefs.getInt("mirror",0),prefs.getInt("flip",0),false);
  Serial.printf("Verified OV2640; native JPEG; PSRAM %u bytes\n",ESP.getPsramSize()); return true;
}
camera_fb_t* capture() {
  if(!ready) return nullptr;
  uint32_t start=micros(); camera_fb_t *fb=esp_camera_fb_get(); captureUs=micros()-start;
  if(!fb || fb->format!=PIXFORMAT_JPEG || fb->len<4 || fb->buf[0]!=0xff || fb->buf[1]!=0xd8 || fb->buf[fb->len-2]!=0xff || fb->buf[fb->len-1]!=0xd9) {
    if(fb) esp_camera_fb_return(fb); failures++; return nullptr;
  }
  captured++; return fb;
}
void status(JsonObject o) {
  o["ready"]=ready.load(); o["pid"]=pid; o["error"]=error; o["format"]="native JPEG";
  o["captured"]=captured; o["failures"]=failures; o["capture_ms"]=captureUs/1000.0;
  if(ready) { auto s=esp_camera_sensor_get(); o["size"]=s->status.framesize; o["quality"]=s->status.quality; o["brightness"]=s->status.brightness; o["contrast"]=s->status.contrast; o["saturation"]=s->status.saturation; o["mirror"]=s->status.hmirror; o["flip"]=s->status.vflip; }
}
bool startBenchmark() {
  if(!ready || benchmarking.exchange(true)) return false;
  portENTER_CRITICAL(&benchMux); resultCount=0; portEXIT_CRITICAL(&benchMux);
  if(xTaskCreate(benchmarkTask,"benchmark",4096,nullptr,1,nullptr)!=pdPASS) { benchmarking=false; return false; } return true;
}
void benchmarkTask(void*) {
  xSemaphoreTake(mutex,portMAX_DELAY);
  auto s=esp_camera_sensor_get(); auto original=s->status;
  const int sizes[]={FRAMESIZE_QVGA,FRAMESIZE_VGA,FRAMESIZE_SVGA,FRAMESIZE_XGA,FRAMESIZE_SXGA,FRAMESIZE_UXGA};
  for(int size:sizes) { if(!psramFound() && size!=FRAMESIZE_QVGA) break;
    for(int quality:{12,20}) {
      Result r={}; r.size=size; r.quality=quality;
      if(!configure(size,quality,0,0,0,0,0,false)) { r.failed=1; }
      else {
        for(int i=0;i<3;i++) { auto f=capture(); if(f) esp_camera_fb_return(f); vTaskDelay(1); }
        uint32_t start=millis();
        for(int i=0;i<30;i++) { auto f=capture(); if(f) {r.frames++;r.bytes+=f->len;esp_camera_fb_return(f);} else r.failed++; vTaskDelay(1); }
        r.ms=millis()-start;
      }
      r.heap=ESP.getFreeHeap();r.psram=ESP.getFreePsram();
      portENTER_CRITICAL(&benchMux); results[resultCount++]=r; portEXIT_CRITICAL(&benchMux);
      if(!ready) break;
    } if(!ready) break;
  }
  if(ready) configure(original.framesize,original.quality,original.brightness,original.contrast,original.saturation,original.hmirror,original.vflip,false);
  xSemaphoreGive(mutex); benchmarking=false; vTaskDelete(nullptr);
}
void benchmarkStatus(JsonObject o) {
  Result copy[12]; int count;
  portENTER_CRITICAL(&benchMux); count=resultCount; memcpy(copy,results,sizeof(results)); portEXIT_CRITICAL(&benchMux);
  o["running"]=busy(); auto a=o.createNestedArray("results");
  for(int i=0;i<count;i++) { auto r=copy[i];auto x=a.createNestedObject();x["size"]=r.size;x["quality"]=r.quality;x["frames"]=r.frames;x["failures"]=r.failed;x["fps"]=r.ms?1000.0*r.frames/r.ms:0;x["mean_bytes"]=r.frames?r.bytes/r.frames:0;x["free_heap"]=r.heap;x["free_psram"]=r.psram; }
}
}
