#pragma once
#include <Arduino.h>
#include <esp_camera.h>
#include <ArduinoJson.h>
namespace Storage { extern bool available; void begin(); bool save(camera_fb_t*,String&); void status(JsonObject); }
