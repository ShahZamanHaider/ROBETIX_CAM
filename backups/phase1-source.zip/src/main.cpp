#include <Arduino.h>
#include "Settings.h"
#include "Camera.h"
#include "Network.h"
#include "Storage.h"
#include "Web.h"
void setup() {
  Serial.begin(115200); delay(500);
  Serial.println("\nROBETIX VISION / Phase 1 / standalone OV2640");
  settingsBegin(); Camera::begin(); Storage::begin(); Network::begin(); webBegin();
  Serial.printf("Heap=%u minimum=%u PSRAM=%u free=%u\n",ESP.getFreeHeap(),ESP.getMinFreeHeap(),ESP.getPsramSize(),ESP.getFreePsram());
}
void loop() { Network::tick(); delay(25); }
