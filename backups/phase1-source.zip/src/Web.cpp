#include "Web.h"
#include "Settings.h"
#include "Camera.h"
#include "Network.h"
#include "Storage.h"
#include "Ui.h"
#include <esp_http_server.h>
#include <esp_timer.h>
#include <WiFi.h>
#include <atomic>
static httpd_handle_t controlServer,streamServer;
static SemaphoreHandle_t authMutex;
static String session; static int64_t sessionAt=0,loginAfter=0;
static std::atomic<uint32_t> streamFrames{0},streamMs{0};
static std::atomic<bool> streaming{false};
static esp_err_t reply(httpd_req_t *r,const char *body,const char *status="200 OK") {
  httpd_resp_set_status(r,status); httpd_resp_set_type(r,"application/json"); httpd_resp_set_hdr(r,"Cache-Control","no-store"); return httpd_resp_send(r,body,HTTPD_RESP_USE_STRLEN);
}
static esp_err_t json(httpd_req_t*r,JsonDocument &d) {String out;serializeJson(d,out);return reply(r,out.c_str());}
static bool authorized(httpd_req_t*r,String *token=nullptr) {
  char cookie[160]={}; if(httpd_req_get_hdr_value_str(r,"Cookie",cookie,sizeof(cookie))!=ESP_OK)return false;
  xSemaphoreTake(authMutex,portMAX_DELAY);
  String expected="rv="+session; bool ok=session.length() && esp_timer_get_time()-sessionAt<12LL*60*60*1000000;
  bool found=false; char *save=nullptr;
  for(char *p=strtok_r(cookie,";",&save);p;p=strtok_r(nullptr,";",&save)) {while(*p==' ')p++;if(expected==p)found=true;}
  if(ok&&found&&token)*token=session;
  xSemaphoreGive(authMutex); return ok&&found;
}
static bool body(httpd_req_t*r,JsonDocument&d) {
  if(r->content_len<=0 || r->content_len>768) return false;
  char b[769];int offset=0;
  while(offset<r->content_len){int n=httpd_req_recv(r,b+offset,r->content_len-offset);if(n<=0)return false;offset+=n;}
  b[offset]=0;return !deserializeJson(d,b);
}
static bool localPost(httpd_req_t*r) {
  char type[64]={};httpd_req_get_hdr_value_str(r,"Content-Type",type,sizeof(type));
  // JSON-only mutation APIs reject cross-origin simple requests; no CORS permissions are issued.
  return strncmp(type,"application/json",16)==0;
}
static esp_err_t handler(httpd_req_t*r) {
  String uri=r->uri;
  if(r->method==HTTP_GET && uri=="/") {httpd_resp_set_type(r,"text/html");httpd_resp_set_hdr(r,"Cache-Control","no-store");httpd_resp_set_hdr(r,"X-Frame-Options","DENY");return httpd_resp_send(r,UI,HTTPD_RESP_USE_STRLEN);}
  if(r->method==HTTP_GET && uri=="/api/session") {StaticJsonDocument<128>d;d["setup"]=adminHash.isEmpty();d["authenticated"]=authorized(r);return json(r,d);}
  if(r->method==HTTP_POST && !localPost(r)) return reply(r,"{\"error\":\"JSON required\"}","415 Unsupported Media Type");
  if(r->method==HTTP_POST && uri=="/api/login") {
    if(esp_timer_get_time()<loginAfter)return reply(r,"{\"error\":\"Wait before retrying login\"}","429 Too Many Requests");
    loginAfter=esp_timer_get_time()+2000000;
    StaticJsonDocument<1024>d;if(!body(r,d))return reply(r,"{\"error\":\"Invalid request\"}","400 Bad Request");
    String pass=d["password"]|"";
    if(adminHash.isEmpty()) {
      if(pass.length()<12 || pass.length()>64)return reply(r,"{\"error\":\"Choose a 12–64 character administrator password\"}","400 Bad Request");
      adminHash=passwordHash(pass);if(!prefs.putString("admin",adminHash)){adminHash="";return reply(r,"{\"error\":\"Settings write failed\"}","500 Internal Server Error");}
    } else if(pass.length()>64 || passwordHash(pass)!=adminHash) return reply(r,"{\"error\":\"Incorrect password\"}","403 Forbidden");
    xSemaphoreTake(authMutex,portMAX_DELAY);session=randomHex(24);sessionAt=esp_timer_get_time();String cookie="rv="+session+"; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200";xSemaphoreGive(authMutex);
    httpd_resp_set_hdr(r,"Set-Cookie",cookie.c_str());return reply(r,"{}");
  }
  if(!authorized(r))return reply(r,"{\"error\":\"Sign in required\"}","401 Unauthorized");
  if(r->method==HTTP_POST && uri=="/api/logout") {xSemaphoreTake(authMutex,portMAX_DELAY);session="";xSemaphoreGive(authMutex);httpd_resp_set_hdr(r,"Set-Cookie","rv=; Path=/; Max-Age=0");return reply(r,"{}");}
  if(r->method==HTTP_GET && uri=="/api/status") {
    StaticJsonDocument<1536>d;
    d["uptime"]=millis()/1000;d["heap"]=ESP.getFreeHeap();d["min_heap"]=ESP.getMinFreeHeap();d["psram"]=ESP.getPsramSize();d["free_psram"]=ESP.getFreePsram();
    d["ip"]=WiFi.localIP().toString();d["ap_ip"]=WiFi.softAPIP().toString();d["connected"]=WiFi.status()==WL_CONNECTED;d["rssi"]=WiFi.RSSI();d["reconnects"]=Network::reconnects.load();d["hotspot"]=prefs.getBool("hotspot",true);d["needs_network_setup"]=!prefs.getBool("netReady",false);d["ap_ssid"]=prefs.getString("apSsid","Robetix-Vision");d["ssid"]=prefs.getString("ssid","");d["streaming"]=streaming.load();d["stream_fps"]=streamMs.load()?streamFrames.load()*1000.0/streamMs.load():0;d["benchmark"]=Camera::busy();
    if(xSemaphoreTake(Camera::mutex,pdMS_TO_TICKS(50))==pdTRUE){Camera::status(d.createNestedObject("camera"));xSemaphoreGive(Camera::mutex);}
    Storage::status(d.createNestedObject("storage"));return json(r,d);
  }
  if(r->method==HTTP_GET && uri=="/api/benchmark") {StaticJsonDocument<4096>d;Camera::benchmarkStatus(d.to<JsonObject>());return json(r,d);}
  if(r->method==HTTP_POST && uri=="/api/benchmark") {return Camera::startBenchmark()?reply(r,"{}","202 Accepted"):reply(r,"{\"error\":\"Camera unavailable or benchmark active\"}","409 Conflict");}
  if(r->method==HTTP_GET && uri=="/api/scan") {
    int n=WiFi.scanComplete();StaticJsonDocument<2048>d;auto a=d.createNestedArray("networks");
    if(n==WIFI_SCAN_FAILED){WiFi.scanNetworks(true);d["running"]=true;}else if(n==WIFI_SCAN_RUNNING)d["running"]=true;
    else {for(int i=0;i<min(n,16);i++){auto x=a.createNestedObject();x["ssid"]=WiFi.SSID(i);x["rssi"]=WiFi.RSSI(i);}WiFi.scanDelete();d["running"]=false;}
    return json(r,d);
  }
  if(r->method==HTTP_POST && uri=="/api/network") {
    StaticJsonDocument<1024>d;if(!body(r,d)||!d["hotspot"].is<bool>())return reply(r,"{\"error\":\"Invalid network settings\"}","400 Bad Request");
    String ssid=d["ssid"]|"",pass=d["password"]|"";bool hotspot=d["hotspot"];
    String apSsid=d["ap_ssid"]|"",apPass=d["ap_password"]|"";
    bool firstSetup=!prefs.getBool("netReady",false);
    if(apPass.isEmpty() && !firstSetup) apPass=prefs.getString("apPass","");
    if(apSsid.isEmpty() || apSsid.length()>32 || apPass.length()<8 || apPass.length()>63 || apPass==SETUP_AP_PASSWORD)
      return reply(r,"{\"error\":\"Choose a hotspot name (1–32 bytes) and your own hotspot password (8–63 characters)\"}","400 Bad Request");
    if(!hotspot && (ssid.isEmpty()||ssid.length()>32||pass.length()>63||(pass.length()>0&&pass.length()<8)))return reply(r,"{\"error\":\"Check SSID and Wi-Fi password lengths\"}","400 Bad Request");
    bool saved=prefs.putString("apSsid",apSsid)>0 && prefs.putString("apPass",apPass)>0;
    if(!hotspot){saved=bool(prefs.putString("ssid",ssid))&&saved;prefs.putString("wifiPass",pass);saved=(prefs.getString("wifiPass","")==pass)&&saved;}
    saved=prefs.putBool("hotspot",hotspot)&&saved;
    if(!saved || !prefs.putBool("netReady",true))return reply(r,"{\"error\":\"Could not save network settings\"}","500 Internal Server Error");
    esp_err_t result=reply(r,"{\"apply_delay_seconds\":2}");Network::changed();return result;
  }
  bool snap=r->method==HTTP_GET&&uri=="/api/snapshot",save=r->method==HTTP_POST&&uri=="/api/storage/snapshot",camera=r->method==HTTP_POST&&uri=="/api/camera";
  if(snap||save||camera) {
    if(Camera::busy()||!Camera::mutex||xSemaphoreTake(Camera::mutex,pdMS_TO_TICKS(2500))!=pdTRUE)return reply(r,"{\"error\":\"Camera busy; retry shortly\"}","503 Service Unavailable");
    esp_err_t ret;
    if(camera){StaticJsonDocument<512>d;bool valid=body(r,d);for(const char*k:{"size","quality","brightness","contrast","saturation","mirror","flip"})valid=valid&&d[k].is<int>();bool ok=valid&&Camera::configure(d["size"],d["quality"],d["brightness"],d["contrast"],d["saturation"],d["mirror"],d["flip"],true);ret=ok?reply(r,"{}"):reply(r,"{\"error\":\"Invalid or failed camera settings\"}","400 Bad Request");}
    else {auto f=Camera::capture();if(!f)ret=reply(r,"{\"error\":\"Capture failed\"}","503 Service Unavailable");else {
      if(save){String path;bool ok=Storage::save(f,path);StaticJsonDocument<192>d;d[ok?"path":"error"]=ok?path:"SD unavailable or write failed";ret=ok?json(r,d):reply(r,"{\"error\":\"SD unavailable or write failed\"}","503 Service Unavailable");}
      else {httpd_resp_set_type(r,"image/jpeg");httpd_resp_set_hdr(r,"Cache-Control","no-store");httpd_resp_set_hdr(r,"Content-Disposition","attachment; filename=robetix.jpg");ret=httpd_resp_send(r,(const char*)f->buf,f->len);}esp_camera_fb_return(f);
    }}xSemaphoreGive(Camera::mutex);return ret;
  }
  return reply(r,"{\"error\":\"Not found\"}","404 Not Found");
}
static esp_err_t stream(httpd_req_t*r) {
  String streamSession;
  if(!authorized(r,&streamSession))return reply(r,"{\"error\":\"Sign in on port 80 first\"}","401 Unauthorized");
  // HTTPD purges request headers after sending the response. Keep the authorized
  // token locally and check revocation without rereading the Cookie header.
  if(Camera::busy()||!Camera::ready)return reply(r,"{\"error\":\"Camera unavailable\"}","503 Service Unavailable");
  streaming=true;streamFrames=0;uint32_t start=millis();esp_err_t err=ESP_OK;
  httpd_resp_set_type(r,"multipart/x-mixed-replace;boundary=rvframe");httpd_resp_set_hdr(r,"Cache-Control","no-store");
  while(!Camera::busy()) {
    xSemaphoreTake(authMutex,portMAX_DELAY);
    bool valid=session.length() && session==streamSession && esp_timer_get_time()-sessionAt<12LL*60*60*1000000;
    xSemaphoreGive(authMutex);if(!valid)break;
    uint32_t frameStart=millis();
    if(xSemaphoreTake(Camera::mutex,pdMS_TO_TICKS(1000))!=pdTRUE)break;
    auto f=Camera::capture();if(!f){xSemaphoreGive(Camera::mutex);break;}
    char head[128];int n=snprintf(head,sizeof(head),"--rvframe\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",unsigned(f->len));
    err=httpd_resp_send_chunk(r,head,n);if(err==ESP_OK)err=httpd_resp_send_chunk(r,(const char*)f->buf,f->len);if(err==ESP_OK)err=httpd_resp_send_chunk(r,"\r\n",2);
    esp_camera_fb_return(f);xSemaphoreGive(Camera::mutex);
    if(err!=ESP_OK)break;streamFrames++;streamMs=millis()-start;
    uint32_t elapsed=millis()-frameStart;vTaskDelay(pdMS_TO_TICKS(elapsed<100?100-elapsed:1));
  }
  streaming=false;return err==ESP_OK?httpd_resp_send_chunk(r,nullptr,0):err;
}
void webBegin() {
  authMutex=xSemaphoreCreateMutex();if(!authMutex||!Camera::mutex){Serial.println("HTTP disabled: mutex allocation failure");return;}
  httpd_config_t config=HTTPD_DEFAULT_CONFIG();config.server_port=80;config.ctrl_port=32768;config.max_uri_handlers=3;config.max_open_sockets=3;config.lru_purge_enable=true;config.stack_size=8192;config.recv_wait_timeout=3;config.send_wait_timeout=2;config.uri_match_fn=httpd_uri_match_wildcard;
  if(httpd_start(&controlServer,&config)==ESP_OK){httpd_uri_t get={};get.uri="/*";get.method=HTTP_GET;get.handler=handler;httpd_register_uri_handler(controlServer,&get);get.method=HTTP_POST;httpd_register_uri_handler(controlServer,&get);}else Serial.println("Control HTTP start failed");
  config.server_port=81;config.ctrl_port=32769;config.max_open_sockets=1;config.lru_purge_enable=false;config.stack_size=4096;
  if(httpd_start(&streamServer,&config)==ESP_OK){httpd_uri_t u={};u.uri="/stream";u.method=HTTP_GET;u.handler=stream;httpd_register_uri_handler(streamServer,&u);}else Serial.println("Stream HTTP start failed");
}




