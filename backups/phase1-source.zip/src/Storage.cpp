#include "Storage.h"
#include <SD_MMC.h>
#include "Settings.h"
namespace Storage {
bool available=false; static String lastError; static uint64_t total=0,used=0;
void begin() {
  pinMode(4,OUTPUT); digitalWrite(4,LOW);
  available=SD_MMC.begin("/sdcard",true,false,SDMMC_FREQ_DEFAULT,2) && SD_MMC.cardType()!=CARD_NONE;
  if(available) { available=SD_MMC.exists("/snapshots") || SD_MMC.mkdir("/snapshots"); }
  if(available) { total=SD_MMC.totalBytes();used=SD_MMC.usedBytes(); }
  else {lastError="No usable SD card. Insert FAT32 card with power off, then reboot."; SD_MMC.end();}
}
bool save(camera_fb_t *fb,String &path) {
  if(!available) return false;
  if(total-used<fb->len+65536) {lastError="Card full; free space using a card reader";return false;}
  path="/snapshots/"+randomHex(8)+".jpg";
  File f=SD_MMC.open(path,FILE_WRITE); bool ok=f && f.write(fb->buf,fb->len)==fb->len;
  if(f){f.flush();f.close();}
  if(!ok) {SD_MMC.remove(path); available=false;lastError="SD write failed; power off and inspect card";return false;}
  used=SD_MMC.usedBytes(); return true;
}
void status(JsonObject o) {o["available"]=available;o["total"]=total;o["used"]=used;o["free"]=total>used?total-used:0;o["error"]=lastError;}
}
