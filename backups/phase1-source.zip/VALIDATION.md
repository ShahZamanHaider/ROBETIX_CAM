# Phase 1 validation

Date: 2026-10-27. No serial devices reported by `platformio device list`.

## Completed

- PlatformIO release build for `esp32cam`, Espressif32 6.11.0 / Arduino 2.0.17.
- Checked camera enums, sensor ID and SD_MMC signatures against installed headers.
- Reviewed framebuffer ownership, capture/configuration exclusion, stream-session revocation and no-card behavior in source.
- Headless Microsoft Edge tests using **simulated API responses**: JavaScript syntax; initial administrator setup/login without a serial setup key; AP/STA mode selection; mandatory first-use hotspot password; AP name/password submission; retained AP settings; router credential submission; reconnection instructions; diagnostics; SD save disabled with no card; fit/fill/reset; camera-settings payload; untrusted SSID text rendering; mobile width at 390 pixels; logout.
- Desktop and mobile screenshot inspection. Test images show fixture data, not hardware measurements.

Reproduce UI checks (development-only dependencies, not firmware/runtime requirements):

```powershell
npm install --prefix .pio/ui-test --no-audit --no-fund playwright
node tools/test-ui.cjs
```

Screenshots are generated under `.pio/ui-test/results/`. This harness requires installed Microsoft Edge. It does not test the C++ HTTP server, Wi-Fi, SD or camera.

## Still required

Actual OV2640 PID/JPEG verification; PSRAM discovery; physical camera field of view; real-device authentication and stream continuity; captured JPEG decoding; SD writes; initial setup AP and switching AP/STA credentials on hardware; router reconnection; mDNS; settings persistence; frame-rate/quality benchmarks; simultaneous stream/SD contention and overnight operation. See the README hardware checklist. No runtime benchmark numbers or successful hardware tests are claimed.
