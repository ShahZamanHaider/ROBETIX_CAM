// Browser contract/layout test with simulated APIs. Does not validate ESP32 hardware.
// npm install --prefix .pio/ui-test --no-audit --no-fund playwright
// node tools/test-ui.cjs
const fs=require('fs'),http=require('http'),path=require('path'),assert=require('assert');
const {chromium}=require('../.pio/ui-test/node_modules/playwright');
const html=fs.readFileSync(path.join(__dirname,'../src/Ui.h'),'utf8').split('R"HTML(')[1].split(')HTML";')[0];
new Function(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
const status={uptime:120,heap:180000,min_heap:170000,psram:4194304,free_psram:3900000,ip:'192.168.1.10',ap_ip:'192.168.4.1',connected:true,rssi:-50,reconnects:1,hotspot:false,ssid:'Local Wi-Fi',streaming:false,stream_fps:0,benchmark:false,camera:{ready:true,pid:38,error:'',size:8,quality:16,brightness:0,contrast:0,saturation:0,mirror:0,flip:0,capture_ms:55,captured:10,failures:0},storage:{available:false,total:0,used:0,free:0,error:'No usable SD card. Insert FAT32 card with power off, then reboot.'}};
let authenticated=false,setup=true,calls=[];
status.hotspot=true;status.needs_network_setup=true;status.ap_ssid='Robetix-Vision';
const server=http.createServer((req,res)=>{
 if(req.url==='/'){res.setHeader('Content-Type','text/html');return res.end(html)}
 let input='';req.on('data',c=>input+=c);req.on('end',()=>{
  calls.push({url:req.url,body:input?JSON.parse(input):null});res.setHeader('Content-Type','application/json');
  const send=d=>res.end(JSON.stringify(d));
  if(req.url==='/api/session')return send({setup,authenticated});
  if(req.url==='/api/login'){authenticated=true;setup=false;return send({})}
  if(!authenticated){res.statusCode=401;return send({error:'Sign in required'})}
  if(req.url==='/api/status')return send(status);
  if(req.url==='/api/benchmark')return send({running:false,results:[]});
  if(req.url==='/api/camera'){Object.assign(status.camera,JSON.parse(input));return send({})}
  if(req.url==='/api/scan')return send({running:false,networks:[{ssid:'<script>unsafe</script>',rssi:-55}]});
  if(req.url==='/api/logout'){authenticated=false;return send({})}
  if(req.url==='/api/network'){const d=JSON.parse(input);status.hotspot=d.hotspot;status.ap_ssid=d.ap_ssid;status.ssid=d.ssid;status.needs_network_setup=false;return send({apply_delay_seconds:2})}
  res.statusCode=404;send({error:'Not found'});
 });
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});let errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto('http://127.0.0.1:'+server.address().port);
  await page.locator('#setupHelp').waitFor({state:'visible'});
  assert.equal(await page.locator('#setupKey').count(),0,'No serial setup key required');
  await page.locator('#password').fill('test-password-123');await page.locator('#loginForm button').click();
  await page.locator('#dashboard').waitFor({state:'visible'});await page.waitForFunction(()=>document.querySelector('#online').textContent==='CAMERA READY');
  assert(await page.locator('#save').isDisabled(),'No-card save must be disabled');
  assert.equal(await page.locator('#feed').evaluate(e=>getComputedStyle(e).objectFit),'contain');
  await page.locator('#fit').selectOption('fill');assert.equal(await page.locator('#feed').evaluate(e=>getComputedStyle(e).objectFit),'cover');
  await page.locator('#resetZoom').click();assert.equal(await page.locator('#fit').inputValue(),'');
  await page.locator('#quality').fill('20');await page.locator('#cameraForm button').click();await page.waitForFunction(()=>document.querySelector('#notice').textContent==='Camera settings applied.');
  assert(calls.some(c=>c.url==='/api/camera'&&c.body.quality===20&&c.body.size===8));
  assert(await page.locator('#networkPanel').evaluate(e=>e.open),'First setup opens network form');
  assert(await page.locator('#routerFields').isHidden(),'AP choice hides router credentials');
  assert(await page.locator('#apPassword').evaluate(e=>e.required),'First setup requires a private AP password');
  await page.locator('#saveNetwork').click();assert(!calls.some(c=>c.url==='/api/network'),'Empty first-run password must not submit');
  await page.locator('#apSsid').fill('My Camera');await page.locator('#apPassword').fill('my-camera-pass');await page.locator('#saveNetwork').click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.startsWith('Settings saved.'));
  assert(calls.some(c=>c.url==='/api/network'&&c.body.hotspot===true&&c.body.ap_ssid==='My Camera'&&c.body.ap_password==='my-camera-pass'));
  await page.reload();await page.waitForFunction(()=>document.querySelector('#online').textContent==='CAMERA READY');
  await page.locator('summary').filter({hasText:/^Network$/}).click();
  assert.equal(await page.locator('#apSsid').inputValue(),'My Camera');assert.equal(await page.locator('#apPassword').inputValue(),'');
  assert(!(await page.locator('#apPassword').evaluate(e=>e.required)),'Configured AP password can be retained');
  await page.locator('#hotspot').selectOption('false');assert(await page.locator('#routerFields').isVisible());
  await page.locator('#scan').click();await page.waitForFunction(()=>document.querySelector('#networks').children.length===1);
  assert.equal(await page.locator('#networks option').getAttribute('value'),'<script>unsafe</script>');
  assert.equal(await page.locator('#networks script').count(),0,'Untrusted SSID must remain text');
  fs.mkdirSync('.pio/ui-test/results',{recursive:true});await page.screenshot({path:'.pio/ui-test/results/desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No horizontal overflow on mobile');
  await page.screenshot({path:'.pio/ui-test/results/mobile.png',fullPage:true});
  await page.locator('#ssid').fill('Home Router');await page.locator('#wifiPassword').fill('router-password');await page.locator('#saveNetwork').click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.startsWith('Settings saved.'));
  assert(calls.some(c=>c.url==='/api/network'&&c.body.hotspot===false&&c.body.ssid==='Home Router'&&c.body.password==='router-password'&&c.body.ap_password===''));
  await page.locator('summary').filter({hasText:/^Access$/}).click();await page.locator('#logout').click();await page.locator('#login').waitFor({state:'visible'});
  assert(await page.locator('#setupHelp').isHidden());assert.deepEqual(errors,[]);
  console.log('PASS: web setup without serial key, AP/STA choice, AP credential validation/submission, retained AP settings, router credential submission, reconnect instructions, status, camera controls, safe SSID rendering, mobile layout and logout. APIs mocked; hardware not tested.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
